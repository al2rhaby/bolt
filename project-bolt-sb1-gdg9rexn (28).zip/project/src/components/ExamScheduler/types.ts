// File: components/ExamScheduler/types.ts

export interface ScheduledExam {
  id: number;
  title: string;
  type: 'TOEFL' | 'Unit';
  date: string;
  time: string;
  duration: string;
  salons: string[];
  carrera: string;
  semestre: string;
  grupo: string;
  profesor: string;
  status: 'upcoming' | 'ongoing' | 'completed';
  test_id?: string;
}

export interface SavedTest {
  id: string;
  title: string;
  type: 'TOEFL' | 'Unit';
  carrera?: string;
  semestre?: string;
  grupo?: string;
  profesor: string;
  salons?: string[];
  hasQuestions?: boolean;
}

export interface NewExamFormData {
  date: string;
  time: string;
  duration: string;
  examName?: string;
}

export interface EditExamFormData {
  date: string;
  time: string;
  duration: string;
}
