// File: components/ExamScheduler/utils.ts

import { supabase } from '../../lib/supabase';
import { ScheduledExam, SavedTest } from './types';

export async function loadSavedTests(): Promise<SavedTest[]> {
  const { data: tests, error: testsError } = await supabase
    .from('tests')
    .select(`
      *,
      questions (
        id,
        type,
        text,
        choices,
        correct_answer
      )
    `)
    .order('created_at', { ascending: false });

  if (testsError) throw testsError;

  // Filter out duplicates and child tests
  const uniqueTests = tests?.filter(test => 
    // For TOEFL tests, only include parent tests
    (test.type === 'TOEFL' && !test.parent_test_id) ||
    // For Unit tests, include tests with questions
    (test.type === 'Unit' && !test.parent_test_id)
  ) || [];

  // Get sections for TOEFL tests
  for (const test of uniqueTests) {
    if (test.type === 'TOEFL') {
      const { data: sections } = await supabase
        .from('tests')
        .select(`
          *,
          questions (
            id,
            type,
            text,
            choices,
            correct_answer
          )
        `)
        .eq('parent_test_id', test.id);

      // Check if sections have questions
      if (sections) {
        test.hasQuestions = sections.some(section => 
          section.questions && section.questions.length > 0
        );
      }
    }
  }

  return uniqueTests;
}

export async function loadScheduledExams(): Promise<ScheduledExam[]> {
  const { data: scheduledExams, error: fetchError } = await supabase
    .from('exam_schedule')
    .select(`
      *,
      tests (
        id,
        title,
        type,
        carrera,
        semestre,
        grupo,
        profesor,
        salons
      )
    `)
    .order('date', { ascending: true });

  if (fetchError) throw fetchError;

  if (!scheduledExams) {
    return [];
  }

  const now = new Date();

  const formattedExams = scheduledExams
    .filter(exam => exam.tests)
    .map((exam) => {
      // Create exam date object
      const examDate = new Date(exam.date + 'T' + exam.time);
      const examEndTime = new Date(examDate.getTime() + (exam.duration * 60000)); // Add duration in minutes

      // Determine status
      let status = 'upcoming';
      if (now > examEndTime) {
        status = 'completed';
      } else if (now >= examDate && now <= examEndTime) {
        status = 'ongoing';
      }

      // Update status in database if it's different
      if (status !== exam.status) {
        supabase
          .from('exam_schedule')
          .update({ status })
          .eq('id', exam.id)
          .then(({ error }) => {
            if (error) console.error('Error updating exam status:', error);
          });
      }

      return {
        id: exam.id,
        title: exam.tests?.title || 'Untitled Exam',
        type: exam.tests?.type || 'Unit',
        date: exam.date,
        time: exam.time,
        duration: exam.duration,
        salons: Array.isArray(exam.tests?.salons) ? exam.tests.salons : [],
        carrera: exam.tests?.carrera || '',
        semestre: exam.tests?.semestre || '',
        grupo: exam.tests?.grupo || '',
        profesor: exam.tests?.profesor || '',
        status,
        test_id: exam.test_id
      };
    });

  return formattedExams;
}

export async function validateAndScheduleExam(
  date: string, 
  time: string, 
  duration: number, 
  testId: string, 
  examId?: number
): Promise<void> {
  // Parse exam date/time
  const examDateTime = new Date(`${date}T${time}`);
  
  // Get current date/time
  const now = new Date();
  
  // Only validate that exam is in the future
  if (examDateTime < now) {
    throw new Error('Exam date and time must be in the future');
  }

  // For TOEFL tests, check if sections have questions
  const { data: test } = await supabase
    .from('tests')
    .select('type')
    .eq('id', testId)
    .single();

  if (test?.type === 'TOEFL') {
    const { data: sections } = await supabase
      .from('tests')
      .select(`
        *,
        questions (
          id,
          type,
          text,
          choices,
          correct_answer
        )
      `)
      .eq('parent_test_id', testId);

    // Check if any section has questions
    const hasQuestions = sections?.some(section => 
      section.questions && section.questions.length > 0
    );

    if (!hasQuestions) {
      throw new Error('Selected TOEFL test has no questions in its sections');
    }
  } else {
    // For Unit tests, check questions directly
    const { data: questions, error: questionsError } = await supabase
      .from('questions')
      .select('*')
      .eq('test_id', testId);

    if (questionsError) throw questionsError;

    if (!questions || questions.length === 0) {
      throw new Error('Selected test has no questions');
    }
  }

  // Check for duplicate exam names on the same date
  const { data: existingExams, error: checkError } = await supabase
    .from('exam_schedule')
    .select('*')
    .eq('test_id', testId)
    .eq('date', date);

  if (checkError) throw checkError;

  if (existingExams && existingExams.length > 0) {
    // Allow multiple exams on the same day as long as they don't overlap
    const examStart = new Date(`${date}T${time}`);
    examStart.setSeconds(0, 0); // Reset seconds and milliseconds
    const examEnd = new Date(examStart.getTime() + duration * 60000);

    const hasOverlap = existingExams.some(exam => {
      // Skip checking against the exam being edited
      if (examId && exam.id === examId) return false;
      
      if (exam.date !== date) return false;
      
      const existingStart = new Date(`${exam.date}T${exam.time}`);
      existingStart.setSeconds(0, 0); // Reset seconds and milliseconds
      const existingEnd = new Date(existingStart.getTime() + exam.duration * 60000);

      return (
        (examStart >= existingStart && examStart < existingEnd) ||
        (examEnd > existingStart && examEnd <= existingEnd) ||
        (examStart <= existingStart && examEnd >= existingEnd)
      );
    });

    if (hasOverlap) {
      throw new Error('This time slot overlaps with another exam. Please choose a different time.');
    }
  }

  const formattedDate = date;
  const formattedTime = time + ':00';

  if (examId) {
    // Update existing exam
    const { error: updateError } = await supabase
      .from('exam_schedule')
      .update({
        date: formattedDate,
        time: formattedTime,
        duration: duration,
        updated_at: new Date().toISOString()
      })
      .eq('id', examId);

    if (updateError) throw updateError;
  } else {
    // Create new exam
    const { error: createError } = await supabase
      .from('exam_schedule')
      .insert([{
        test_id: testId,
        date: formattedDate,
        time: formattedTime,
        duration: duration,
        status: 'upcoming'
      }]);

    if (createError) throw createError;
  }
}

export function formatDate(dateStr: string): string {
  try {
    // Split the date string and create parts
    const [year, month, day] = dateStr.split('-').map(Number);
    // Create date without timezone conversion
    return new Date(year, month - 1, day).toLocaleDateString();
  } catch (err) {
    return 'Invalid Date';
  }
}

export function getStatusColor(status: ScheduledExam['status']): string {
  switch (status) {
    case 'ongoing':
      return 'bg-green-100 text-green-700';
    case 'upcoming':
      return 'bg-blue-100 text-blue-700';
    case 'completed':
      return 'bg-gray-100 text-gray-700';
    default:
      return 'bg-gray-100 text-gray-700';
  }
}
