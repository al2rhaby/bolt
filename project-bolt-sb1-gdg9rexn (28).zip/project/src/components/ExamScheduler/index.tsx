// File: components/ExamScheduler/index.tsx
// This will be the main file that imports and composes all the parts

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Plus, Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

// Import components
import ExamSchedulerHeader from './ExamSchedulerHeader';
import ExamList from './ExamList';
import NewExamModal from './modals/NewExamModal';
import EditExamModal from './modals/EditExamModal';
import StartImmediateExamModal from './modals/StartImmediateExamModal';
import { ScheduledExam, SavedTest } from './types';
import { loadScheduledExams, loadSavedTests, validateAndScheduleExam } from './utils';

export default function ExamScheduler() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exams, setExams] = useState<ScheduledExam[]>([]);
  const [showNewExam, setShowNewExam] = useState(false);
  const [selectedTest, setSelectedTest] = useState<SavedTest | null>(null);
  const [savedTests, setSavedTests] = useState<SavedTest[]>([]);
  const [showEditExam, setShowEditExam] = useState(false);
  const [examToEdit, setExamToEdit] = useState<ScheduledExam | null>(null);
  const [newExam, setNewExam] = useState({
    date: '',
    time: '',
    duration: '90',
    examName: '' // Added for immediate exams
  });
  const [editExam, setEditExam] = useState({
    date: '',
    time: '',
    duration: ''
  });
  const [showStartImmediateExam, setShowStartImmediateExam] = useState(false);
  const [immediateExam, setImmediateExam] = useState<SavedTest | null>(null);

  useEffect(() => {
    fetchScheduledExams();
    fetchSavedTests();

    // Set up interval to check exam status every minute
    const statusInterval = setInterval(() => {
      fetchScheduledExams();
    }, 60000); // 60000 ms = 1 minute

    // Cleanup interval on component unmount
    return () => clearInterval(statusInterval);
  }, []);

  useEffect(() => {
    if (location.state?.test) {
      setSelectedTest(location.state.test);
      setShowNewExam(true);
    }
  }, [location.state]);

  const fetchSavedTests = async () => {
    try {
      const tests = await loadSavedTests();
      setSavedTests(tests);
    } catch (err) {
      console.error('Error loading tests:', err);
      setError('Failed to load available tests');
    }
  };

  const fetchScheduledExams = async () => {
    try {
      setLoading(true);
      setError(null);
      const formattedExams = await loadScheduledExams();
      setExams(formattedExams);
    } catch (err) {
      console.error('Error loading exams:', err);
      setError('Failed to load scheduled exams');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateExam = async () => {
    try {
      // Basic validation
      if (!newExam.date || !newExam.time || !newExam.duration || !selectedTest?.id) {
        setError('Please fill in all required fields and select a test');
        return; 
      }

      await validateAndScheduleExam(
        newExam.date, 
        newExam.time, 
        parseInt(newExam.duration), 
        selectedTest.id
      );

      setShowNewExam(false);
      setSelectedTest(null);
      setNewExam({
        date: '',
        time: '',
        duration: '90',
        examName: ''
      });

      await fetchScheduledExams();

      if (location.state?.test) {
        navigate(-1);
      }
    } catch (err) {
      console.error('Error creating exam:', err);
      setError(err instanceof Error ? err.message : 'Failed to create exam schedule');
    }
  };

  const handleEditExam = async () => {
    try {
      if (!examToEdit || !editExam.date || !editExam.time || !editExam.duration) {
        setError('Please fill in all required fields');
        return;
      }

      await validateAndScheduleExam(
        editExam.date, 
        editExam.time, 
        parseInt(editExam.duration), 
        examToEdit.test_id || '',
        examToEdit.id
      );

      setShowEditExam(false);
      setExamToEdit(null);
      setEditExam({
        date: '',
        time: '',
        duration: ''
      });

      await fetchScheduledExams();
    } catch (err) {
      console.error('Error updating exam:', err);
      setError(err instanceof Error ? err.message : 'Failed to update exam schedule');
    }
  };

  // Format date for Mexico City timezone (UTC-6)
  const getMexicoCityDate = () => {
    const now = new Date();
    
    // Convert to Mexico City time (UTC-6)
    const mexicoTimeOptions = { timeZone: 'America/Mexico_City' };
    
    // Get date components in Mexico City timezone
    const year = now.toLocaleString('en-US', { ...mexicoTimeOptions, year: 'numeric' });
    const month = now.toLocaleString('en-US', { ...mexicoTimeOptions, month: '2-digit' });
    const day = now.toLocaleString('en-US', { ...mexicoTimeOptions, day: '2-digit' });
    
    // Format as YYYY-MM-DD for HTML inputs
    return `${year}-${month}-${day}`;
  };
  
  // Format time for Mexico City timezone (UTC-6)
  const getMexicoCityTime = () => {
    const now = new Date();
    
    // Get time in Mexico City
    const mexicoTimeOptions = { timeZone: 'America/Mexico_City', hour12: false };
    const timeString = now.toLocaleString('en-US', {
      ...mexicoTimeOptions,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    
    // Extract hours and minutes from the time string
    const timeParts = timeString.split(':');
    return `${timeParts[0]}:${timeParts[1]}:${timeParts[2]}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <ExamSchedulerHeader 
        onNewExam={() => setShowNewExam(true)}
        onStartImmediateExam={() => setShowStartImmediateExam(true)}
        isPreselectedTest={!!location.state?.test}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ExamList 
          exams={exams}
          loading={loading}
          error={error}
          onRetryLoad={fetchScheduledExams}
          onEditExam={(exam) => {
            setExamToEdit(exam);
            setEditExam({
              date: exam.date,
              time: exam.time,
              duration: exam.duration.toString()
            });
            setShowEditExam(true);
          }}
        />
      </div>

      {/* Modals */}
      {showNewExam && (
        <NewExamModal
          onClose={() => {
            setShowNewExam(false);
            setSelectedTest(null);
            setNewExam({
              date: '',
              time: '',
              duration: '90',
              examName: ''
            });
          }}
          onSchedule={handleCreateExam}
          newExam={newExam}
          setNewExam={setNewExam}
          selectedTest={selectedTest}
          setSelectedTest={setSelectedTest}
          savedTests={savedTests}
          error={error}
          isPreselectedTest={!!location.state?.test}
        />
      )}

      {showEditExam && examToEdit && (
        <EditExamModal
          onClose={() => {
            setShowEditExam(false);
            setExamToEdit(null);
            setEditExam({
              date: '',
              time: '',
              duration: ''
            });
          }}
          onUpdate={handleEditExam}
          editExam={editExam}
          setEditExam={setEditExam}
          error={error}
        />
      )}

      {showStartImmediateExam && (
        <StartImmediateExamModal
          onClose={() => {
            setShowStartImmediateExam(false);
            setImmediateExam(null);
            setNewExam({
              ...newExam,
              examName: ''
            });
          }}
          onStart={async () => {
            try {
              if (!immediateExam) {
                setError('Please select a test');
                return;
              }

              if (!newExam.examName) {
                setError('Please provide an exam name');
                return;
              }

              // Get current date and time in Mexico City timezone
              const date = getMexicoCityDate();
              const time = getMexicoCityTime();

              // Use appropriate duration based on test type
              const duration = immediateExam.type === 'TOEFL' ? 180 : parseInt(newExam.duration);

              // Create immediate exam - FIXED: Removed the title field from the insert
              const { error: createError } = await supabase
                .from('exam_schedule')
                .insert([{
                  test_id: immediateExam.id,
                  date: date,
                  time: time,
                  duration: duration,
                  // Remove the title field that's causing the error
                  status: 'ongoing'
                }]);

              if (createError) throw createError;

              await fetchScheduledExams();
              setShowStartImmediateExam(false);
              setImmediateExam(null);
              setNewExam({
                date: '',
                time: '',
                duration: '90',
                examName: ''
              });
            } catch (err) {
              console.error('Error starting immediate exam:', err);
              setError('Failed to start immediate exam');
            }
          }}
          immediateExam={immediateExam}
          setImmediateExam={setImmediateExam}
          newExam={newExam}
          setNewExam={setNewExam}
          savedTests={savedTests}
          error={error}
        />
      )}
    </div>
  );
}