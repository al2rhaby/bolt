-- Add section_duration column to tests table
ALTER TABLE tests 
ADD COLUMN IF NOT EXISTS section_duration integer;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_tests_section_duration ON tests(section_duration);

-- Set default durations for existing sections
UPDATE tests 
SET section_duration = 
  CASE 
    WHEN section = 'listening' THEN 35
    WHEN section = 'structure' THEN 40
    WHEN section = 'reading' THEN 40
    ELSE 35
  END
WHERE section IS NOT NULL;