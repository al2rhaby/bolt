/*
  # Add Reading Passages Support

  1. New Tables
    - `passages` table to store reading passages
      - `id` (uuid, primary key)
      - `title` (text)
      - `content` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Changes
    - Add passage reference to questions table
    - Add indexes for better performance

  3. Security
    - Enable RLS on passages table
    - Add policies for passage access
*/

-- Create passages table
CREATE TABLE IF NOT EXISTS passages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add passage reference to questions
ALTER TABLE questions
ADD COLUMN IF NOT EXISTS passage_id uuid REFERENCES passages(id) ON DELETE CASCADE;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_questions_passage_id ON questions(passage_id);

-- Enable RLS
ALTER TABLE passages ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_all_operations"
  ON passages
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_passages_updated_at
  BEFORE UPDATE ON passages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();