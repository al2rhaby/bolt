/*
  # Add Unit Exam Questions Support

  1. Changes
    - Add section column to questions table for unit exams
    - Add indexes for better performance
    - Add foreign key relationship between questions and tests
*/

-- Add section column to questions table if it doesn't exist
ALTER TABLE questions 
ADD COLUMN IF NOT EXISTS section text;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_section ON questions(section);
CREATE INDEX IF NOT EXISTS idx_questions_test_type ON questions(test_id, type);

-- Add composite index for unit exam questions
CREATE INDEX IF NOT EXISTS idx_unit_exam_questions ON questions(test_id, section, type);