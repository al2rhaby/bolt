-- Drop existing policies
DROP POLICY IF EXISTS "Teachers can manage all students" ON students;
DROP POLICY IF EXISTS "Students can read own data" ON students;
DROP POLICY IF EXISTS "Allow student registration" ON students;

-- Create new policies for students table
CREATE POLICY "Teachers can view all students"
  ON students
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Teachers can manage students"
  ON students
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "Students can read own data"
  ON students
  FOR SELECT
  TO authenticated
  USING (auth.email() = email);

CREATE POLICY "Allow student registration"
  ON students
  FOR INSERT
  TO authenticated
  WITH CHECK (true);