/*
  # Add Student Registration Policy
  
  1. Changes
    - Drop existing policy if it exists to prevent conflicts
    - Add new policy to allow student registration
    - Policy allows any authenticated user to register
    - Uniqueness constraints on email and matricula are handled by the table constraints
*/

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Allow student registration" ON students;

-- Add policy for student registration
CREATE POLICY "Allow student registration"
  ON students
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Note: Uniqueness is already enforced by UNIQUE constraints on email and matricula columns
-- No need for additional checks in the policy since the database constraints will handle this