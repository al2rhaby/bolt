-- Add passage-related columns to questions table
ALTER TABLE questions 
ADD COLUMN IF NOT EXISTS passage_id uuid,
ADD COLUMN IF NOT EXISTS passage_title text,
ADD COLUMN IF NOT EXISTS passage_content text;

-- Add salon column to exam_schedule
ALTER TABLE exam_schedule 
ADD COLUMN IF NOT EXISTS salon text;

-- Drop existing policies
DROP POLICY IF EXISTS "teacher_manage_schedule" ON exam_schedule;
DROP POLICY IF EXISTS "student_view_schedule" ON exam_schedule;

-- Create new policies for exam_schedule
CREATE POLICY "allow_teacher_schedule_management"
  ON exam_schedule
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "allow_student_schedule_viewing"
  ON exam_schedule
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = exam_schedule.salon
      AND students.email = auth.email()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_exam_schedule_salon ON exam_schedule(salon);
CREATE INDEX IF NOT EXISTS idx_questions_passage_id ON questions(passage_id);