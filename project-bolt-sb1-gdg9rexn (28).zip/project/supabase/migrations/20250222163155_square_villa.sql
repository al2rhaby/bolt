/*
  # Fix Test Level Validation

  1. Changes
    - Update tests table level check constraint to match UI values
    - Add index for level column
*/

-- Drop existing level check constraint if it exists
ALTER TABLE tests DROP CONSTRAINT IF EXISTS tests_level_check;

-- Add new level check constraint with correct values
ALTER TABLE tests
ADD CONSTRAINT tests_level_check
CHECK (level IN ('Basic', 'Intermediate', 'Advanced'));

-- Add index for level column
CREATE INDEX IF NOT EXISTS idx_tests_level ON tests(level);