/*
  # Add Student Registration Policy

  1. Changes
    - Add new policy to allow student registration
    - Keep existing policies intact

  2. Security
    - Allows authenticated users to insert new student records
    - Maintains existing RLS policies for data access
*/

-- Add policy for student registration
CREATE POLICY "Allow student registration"
  ON students
  FOR INSERT
  TO authenticated
  WITH CHECK (true);