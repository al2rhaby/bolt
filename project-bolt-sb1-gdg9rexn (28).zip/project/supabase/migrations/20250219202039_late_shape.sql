/*
  # Fix Test Table Policies

  1. Changes
    - Drop existing policies
    - Add new policy for teacher access
    - Add policy for student test viewing
    - Add performance indexes

  2. Security
    - Enable RLS on tests table
    - Add policies for test access control
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Teachers can manage all tests" ON tests;
DROP POLICY IF EXISTS "Students can view assigned tests" ON tests;

-- Create new policies for tests table
CREATE POLICY "Teachers can manage tests"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "Students can view assigned tests"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS tests_level_idx ON tests(level);
CREATE INDEX IF NOT EXISTS tests_salon_idx ON tests(salon);
CREATE INDEX IF NOT EXISTS tests_semestre_idx ON tests(semestre);
CREATE INDEX IF NOT EXISTS tests_type_idx ON tests(type);