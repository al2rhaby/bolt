/*
  # TOEFL Folder System Schema

  1. New Tables
    - `toefl_folders`: Parent table for organizing TOEFL tests
    - `toefl_sections`: Sections within each TOEFL test (Listening, Structure, Reading)
    - `toefl_questions`: Questions for each section

  2. Security
    - Enable RLS on all tables
    - Add policies for teacher access
    - Add policies for student access

  3. Relationships
    - Folders contain sections
    - Sections contain questions
*/

-- Create TOEFL folders table
CREATE TABLE IF NOT EXISTS toefl_folders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  created_by text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create TOEFL sections table
CREATE TABLE IF NOT EXISTS toefl_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  folder_id uuid REFERENCES toefl_folders(id) ON DELETE CASCADE,
  section_type text NOT NULL CHECK (section_type IN ('Listening', 'Structure', 'Reading')),
  audio_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create TOEFL questions table
CREATE TABLE IF NOT EXISTS toefl_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id uuid REFERENCES toefl_sections(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('multiple', 'matching', 'truefalse')),
  text text NOT NULL,
  choices jsonb,
  correct_answer jsonb NOT NULL,
  passage_id uuid,
  passage_title text,
  passage_content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE toefl_folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE toefl_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE toefl_questions ENABLE ROW LEVEL SECURITY;

-- Create policies for toefl_folders
CREATE POLICY "teacher_manage_folders"
  ON toefl_folders
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create policies for toefl_sections
CREATE POLICY "teacher_manage_sections"
  ON toefl_sections
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create policies for toefl_questions
CREATE POLICY "teacher_manage_questions"
  ON toefl_questions
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_toefl_sections_folder ON toefl_sections(folder_id);
CREATE INDEX IF NOT EXISTS idx_toefl_questions_section ON toefl_questions(section_id);
CREATE INDEX IF NOT EXISTS idx_toefl_sections_type ON toefl_sections(section_type);

-- Add updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_toefl_folders_updated_at
  BEFORE UPDATE ON toefl_folders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_toefl_sections_updated_at
  BEFORE UPDATE ON toefl_sections
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_toefl_questions_updated_at
  BEFORE UPDATE ON toefl_questions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();