/*
  # Disable Questions Table Security

  1. Changes
    - Disable RLS on questions table
    - Drop all existing policies
    - Allow unrestricted access
*/

-- Disable RLS completely
ALTER TABLE questions DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "teacher_full_access" ON questions;
DROP POLICY IF EXISTS "student_view_only" ON questions;
DROP POLICY IF EXISTS "allow_all_operations" ON questions;