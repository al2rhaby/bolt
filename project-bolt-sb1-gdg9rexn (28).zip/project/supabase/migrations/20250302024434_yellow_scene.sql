/*
  # Fix exam tables and relationships

  1. Changes
    - Add student_progress table with proper constraints
    - Update exam_results table structure
    - Add proper foreign key relationships
    - Add indexes for performance
    - Add RLS policies

  2. Tables Modified
    - student_progress (new)
    - exam_results (modified)

  3. Security
    - Enable RLS
    - Add policies for student and teacher access
*/

-- Create student_progress table
CREATE TABLE IF NOT EXISTS student_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE,
  sections_completed text[] DEFAULT '{}',
  last_activity timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(student_id, exam_id)
);

-- Update exam_results table
ALTER TABLE exam_results
ADD COLUMN IF NOT EXISTS test_id uuid REFERENCES exam_schedule(id),
ADD COLUMN IF NOT EXISTS status text CHECK (status IN ('completed', 'incomplete')),
ADD COLUMN IF NOT EXISTS completion_time timestamptz;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_student_progress_student ON student_progress(student_id);
CREATE INDEX IF NOT EXISTS idx_student_progress_exam ON student_progress(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_student ON exam_results(student_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_test ON exam_results(test_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_status ON exam_results(status);

-- Enable RLS
ALTER TABLE student_progress ENABLE ROW LEVEL SECURITY;

-- Create policies for student_progress
CREATE POLICY "Students can manage their own progress"
  ON student_progress
  FOR ALL
  TO authenticated
  USING (auth.uid()::text = student_id::text)
  WITH CHECK (auth.uid()::text = student_id::text);

CREATE POLICY "Teachers can view all progress"
  ON student_progress
  FOR SELECT
  TO authenticated
  USING (auth.email() = 'mohamed');

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_student_progress_updated_at
  BEFORE UPDATE ON student_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();