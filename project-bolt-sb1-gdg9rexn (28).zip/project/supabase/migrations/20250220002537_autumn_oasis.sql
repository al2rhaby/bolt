/*
  # Disable RLS for Passages Table

  1. Changes
    - Disable RLS on passages table
    - Drop all existing policies
    - Keep indexes for performance
*/

-- Disable RLS on passages table
ALTER TABLE passages DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "teacher_manage_passages" ON passages;
DROP POLICY IF EXISTS "student_view_passages" ON passages;
DROP POLICY IF EXISTS "allow_all_operations" ON passages;

-- Keep existing indexes for performance
CREATE INDEX IF NOT EXISTS idx_passages_test_id ON passages(test_id);
CREATE INDEX IF NOT EXISTS idx_passages_created_at ON passages(created_at);