/*
  # Fix underline questions schema

  1. Changes
    - Drop existing constraint
    - Add new columns for underline questions
    - Update check constraint to properly handle all question types
    - Add indexes for better performance

  2. Security
    - Maintain existing RLS policies
*/

-- First, drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;

-- Make sure all columns exist
DO $$ 
BEGIN
  -- For underline questions
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'underlined_words'
  ) THEN
    ALTER TABLE questions ADD COLUMN underlined_words jsonb;
  END IF;
END $$;

-- Update any existing underline questions to have proper structure
UPDATE questions 
SET choices = NULL,
    correct_answer = NULL,
    left_items = NULL,
    right_items = NULL,
    correct_pairs = NULL,
    is_true = NULL
WHERE type = 'underline';

-- Add new type check constraint
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  -- Multiple choice questions
  (
    type = 'multiple' AND 
    correct_answer IS NOT NULL AND 
    choices IS NOT NULL AND
    underlined_words IS NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  ) OR
  -- Underline questions  
  (
    type = 'underline' AND 
    underlined_words IS NOT NULL AND
    choices IS NULL AND
    correct_answer IS NOT NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  ) OR
  -- Matching questions
  (
    type = 'matching' AND 
    correct_answer IS NULL AND 
    choices IS NULL AND
    underlined_words IS NULL AND
    left_items IS NOT NULL AND 
    right_items IS NOT NULL AND 
    correct_pairs IS NOT NULL AND
    is_true IS NULL
  ) OR
  -- True/false questions
  (
    type = 'truefalse' AND 
    correct_answer IS NOT NULL AND
    choices IS NOT NULL AND
    underlined_words IS NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  )
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);
CREATE INDEX IF NOT EXISTS idx_questions_underlined_words ON questions USING gin(underlined_words);