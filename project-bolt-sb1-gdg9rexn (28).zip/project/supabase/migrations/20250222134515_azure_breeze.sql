/*
  # Add test_id relationship to exam_results table

  1. Changes
    - Add test_id column to exam_results table
    - Create foreign key relationship with tests table
    - Add index for better performance
*/

-- Add test_id column if it doesn't exist
ALTER TABLE exam_results 
ADD COLUMN IF NOT EXISTS test_id uuid REFERENCES tests(id) ON DELETE SET NULL;

-- Create index for the foreign key
CREATE INDEX IF NOT EXISTS idx_exam_results_test_id ON exam_results(test_id);

-- Add composite index for common queries
CREATE INDEX IF NOT EXISTS idx_exam_results_type_test ON exam_results(exam_type, test_id);