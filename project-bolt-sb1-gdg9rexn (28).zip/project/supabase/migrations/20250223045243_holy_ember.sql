-- First, drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;

-- Make sure underlined_words column exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'underlined_words'
  ) THEN
    ALTER TABLE questions ADD COLUMN underlined_words jsonb;
  END IF;
END $$;

-- Clean up existing data
UPDATE questions 
SET choices = CASE 
      WHEN type = 'multiple' OR type = 'truefalse' THEN choices 
      ELSE NULL 
    END,
    correct_answer = CASE 
      WHEN type = 'multiple' OR type = 'truefalse' OR type = 'underline' THEN correct_answer 
      ELSE NULL 
    END,
    underlined_words = CASE 
      WHEN type = 'underline' THEN underlined_words 
      ELSE NULL 
    END,
    left_items = CASE 
      WHEN type = 'matching' THEN left_items 
      ELSE NULL 
    END,
    right_items = CASE 
      WHEN type = 'matching' THEN right_items 
      ELSE NULL 
    END,
    correct_pairs = CASE 
      WHEN type = 'matching' THEN correct_pairs 
      ELSE NULL 
    END,
    is_true = CASE 
      WHEN type = 'truefalse' THEN is_true 
      ELSE NULL 
    END;

-- Add new type check constraint
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  -- Multiple choice questions
  (
    type = 'multiple' AND 
    correct_answer IS NOT NULL AND 
    choices IS NOT NULL AND
    underlined_words IS NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  ) OR
  -- Underline questions  
  (
    type = 'underline' AND 
    underlined_words IS NOT NULL AND
    correct_answer IS NOT NULL AND
    choices IS NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  ) OR
  -- Matching questions
  (
    type = 'matching' AND 
    correct_answer IS NULL AND 
    choices IS NULL AND
    underlined_words IS NULL AND
    left_items IS NOT NULL AND 
    right_items IS NOT NULL AND 
    correct_pairs IS NOT NULL AND
    is_true IS NULL
  ) OR
  -- True/false questions
  (
    type = 'truefalse' AND 
    correct_answer IS NOT NULL AND
    choices IS NOT NULL AND
    underlined_words IS NULL AND
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL AND
    is_true IS NULL
  )
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);
CREATE INDEX IF NOT EXISTS idx_questions_underlined_words ON questions USING gin(underlined_words);