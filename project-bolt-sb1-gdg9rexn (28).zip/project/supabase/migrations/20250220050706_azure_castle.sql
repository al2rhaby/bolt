/*
  # Fix Questions Schema

  1. Changes
    - Add correct_pairs column for matching questions
    - Add left_items and right_items columns for matching questions
    - Update column types to handle all question formats

  2. Schema Updates
    - questions table gets new columns for matching questions
    - Ensure all columns can handle NULL values for different question types
*/

-- Add new columns for matching questions if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'correct_pairs'
  ) THEN
    ALTER TABLE questions ADD COLUMN correct_pairs jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'left_items'
  ) THEN
    ALTER TABLE questions ADD COLUMN left_items jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'right_items'
  ) THEN
    ALTER TABLE questions ADD COLUMN right_items jsonb;
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);
CREATE INDEX IF NOT EXISTS idx_questions_test_id ON questions(test_id);