/*
  # Fix Test-Passages Relationship

  1. Changes
    - Add test_id to passages table
    - Create relationship between tests and passages
    - Update indexes for better performance

  2. Security
    - Maintain existing RLS policies
*/

-- Add test_id to passages table
ALTER TABLE passages
ADD COLUMN IF NOT EXISTS test_id uuid REFERENCES tests(id) ON DELETE CASCADE;

-- Create index for the new relationship
CREATE INDEX IF NOT EXISTS idx_passages_test_id ON passages(test_id);

-- Update the questions table to ensure proper relationships
ALTER TABLE questions
DROP CONSTRAINT IF EXISTS questions_passage_id_fkey,
ADD CONSTRAINT questions_passage_id_fkey 
  FOREIGN KEY (passage_id) 
  REFERENCES passages(id) 
  ON DELETE CASCADE;

-- Create composite index for efficient querying
CREATE INDEX IF NOT EXISTS idx_questions_test_passage ON questions(test_id, passage_id);