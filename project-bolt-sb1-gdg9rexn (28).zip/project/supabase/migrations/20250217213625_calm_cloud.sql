-- Drop existing policies
DROP POLICY IF EXISTS "Teachers can manage all students" ON students;
DROP POLICY IF EXISTS "Students can read own data" ON students;
DROP POLICY IF EXISTS "Allow student registration" ON students;
DROP POLICY IF EXISTS "Teachers can view all students" ON students;
DROP POLICY IF EXISTS "Teachers can manage students" ON students;

-- Create new policies for students table
CREATE POLICY "Teachers can view all students"
  ON students
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Teachers can manage students"
  ON students
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "Students can read own data"
  ON students
  FOR SELECT
  TO authenticated
  USING (auth.email() = email);

CREATE POLICY "Allow student registration"
  ON students
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS students_email_idx ON students(email);
CREATE INDEX IF NOT EXISTS students_matricula_idx ON students(matricula);