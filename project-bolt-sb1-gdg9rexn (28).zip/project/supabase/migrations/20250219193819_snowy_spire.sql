/*
  # Questions and Tests Schema

  1. New Tables
    - `tests`
      - `id` (uuid, primary key)
      - `title` (text)
      - `type` (text) - 'TOEFL' or 'Unit'
      - `level` (text) - For Unit exams: 'Basic', 'Intermedio', 'Advanced'
      - `carrera` (text)
      - `semestre` (text)
      - `grupo` (text)
      - `profesor` (text)
      - `salon` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `questions`
      - `id` (uuid, primary key)
      - `test_id` (uuid, foreign key)
      - `type` (text) - 'multiple', 'matching', 'truefalse'
      - `text` (text)
      - `choices` (jsonb) - For multiple choice and matching
      - `correct_answer` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for teacher access
*/

-- Create tests table
CREATE TABLE IF NOT EXISTS tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  type text NOT NULL CHECK (type IN ('TOEFL', 'Unit')),
  level text CHECK (level IN ('Basic', 'Intermedio', 'Advanced')),
  carrera text,
  semestre text,
  grupo text,
  profesor text,
  salon text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create questions table
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('multiple', 'matching', 'truefalse')),
  text text NOT NULL,
  choices jsonb,
  correct_answer jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Teachers can manage all tests"
  ON tests
  FOR ALL
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "Teachers can manage all questions"
  ON questions
  FOR ALL
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create indexes
CREATE INDEX IF NOT EXISTS tests_type_idx ON tests(type);
CREATE INDEX IF NOT EXISTS questions_test_id_idx ON questions(test_id);