/*
  # Fix exam progress and results tracking

  1. Changes
    - Add student progress tracking
    - Update exam results structure
    - Add proper indexes and constraints
    - Update RLS policies

  2. Security
    - Enable RLS on all tables
    - Add proper policies for students and teachers
*/

-- Create student_progress table
CREATE TABLE IF NOT EXISTS student_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  exam_id uuid NOT NULL REFERENCES exam_schedule(id) ON DELETE CASCADE,
  sections_completed text[] DEFAULT ARRAY[]::text[],
  last_activity timestamptz DEFAULT CURRENT_TIMESTAMP,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(student_id, exam_id)
);

-- Update exam_results table
ALTER TABLE exam_results 
DROP CONSTRAINT IF EXISTS exam_results_test_id_fkey;

ALTER TABLE exam_results
ADD COLUMN IF NOT EXISTS exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS status text CHECK (status IN ('completed', 'incomplete')),
ADD COLUMN IF NOT EXISTS completion_time timestamptz DEFAULT CURRENT_TIMESTAMP;

-- Update student_answers table
ALTER TABLE student_answers
ADD COLUMN IF NOT EXISTS exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_student_progress_student ON student_progress(student_id);
CREATE INDEX IF NOT EXISTS idx_student_progress_exam ON student_progress(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_student ON exam_results(student_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_exam ON exam_results(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_status ON exam_results(status);
CREATE INDEX IF NOT EXISTS idx_student_answers_exam ON student_answers(exam_id);

-- Enable RLS
ALTER TABLE student_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_answers ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "student_progress_policy" ON student_progress;
DROP POLICY IF EXISTS "teacher_progress_policy" ON student_progress;
DROP POLICY IF EXISTS "student_answers_policy" ON student_answers;
DROP POLICY IF EXISTS "teacher_answers_policy" ON student_answers;
DROP POLICY IF EXISTS "student_results_policy" ON exam_results;
DROP POLICY IF EXISTS "teacher_results_policy" ON exam_results;

-- Create unified policies
CREATE POLICY "manage_student_progress"
  ON student_progress
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

CREATE POLICY "manage_exam_results"
  ON exam_results
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

CREATE POLICY "manage_student_answers"
  ON student_answers
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

-- Create function for handling student progress
CREATE OR REPLACE FUNCTION handle_student_progress(
  p_student_id uuid,
  p_exam_id uuid,
  p_section text
) RETURNS void AS $$
BEGIN
  INSERT INTO student_progress (
    student_id,
    exam_id,
    sections_completed,
    last_activity
  ) 
  VALUES (
    p_student_id,
    p_exam_id,
    ARRAY[p_section],
    CURRENT_TIMESTAMP
  )
  ON CONFLICT (student_id, exam_id) 
  DO UPDATE SET
    sections_completed = array_append(
      student_progress.sections_completed,
      p_section
    ),
    last_activity = CURRENT_TIMESTAMP,
    updated_at = CURRENT_TIMESTAMP
  WHERE 
    NOT (p_section = ANY(student_progress.sections_completed));
END;
$$ LANGUAGE plpgsql;