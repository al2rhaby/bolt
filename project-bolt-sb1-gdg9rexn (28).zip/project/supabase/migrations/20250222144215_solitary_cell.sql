/*
  # Fix question type constraints

  1. Changes
    - Drop existing constraint
    - Add new constraint with proper handling for each question type
    - Make correct_answer nullable
    - Add proper validation for choices field

  2. Constraints
    - Multiple choice: requires correct_answer and choices
    - Matching: requires left_items, right_items, and correct_pairs
    - True/false: requires is_true and choices
*/

-- Drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;

-- Make correct_answer nullable
ALTER TABLE questions ALTER COLUMN correct_answer DROP NOT NULL;

-- Add new type check constraint with proper validation
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  -- Multiple choice questions
  (
    type = 'multiple' AND 
    correct_answer IS NOT NULL AND 
    choices IS NOT NULL AND
    is_true IS NULL AND 
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL
  ) OR
  -- Matching questions
  (
    type = 'matching' AND 
    correct_answer IS NULL AND 
    choices IS NULL AND
    is_true IS NULL AND 
    left_items IS NOT NULL AND 
    right_items IS NOT NULL AND 
    correct_pairs IS NOT NULL
  ) OR
  -- True/false questions
  (
    type = 'truefalse' AND 
    correct_answer IS NULL AND
    is_true IS NOT NULL AND 
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL
  )
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type_test ON questions(type, test_id);
CREATE INDEX IF NOT EXISTS idx_questions_matching ON questions(test_id) WHERE type = 'matching';
CREATE INDEX IF NOT EXISTS idx_questions_truefalse ON questions(test_id) WHERE type = 'truefalse';
CREATE INDEX IF NOT EXISTS idx_questions_multiple ON questions(test_id) WHERE type = 'multiple';