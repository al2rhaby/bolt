/*
  # Fix exam schedule questions storage

  1. Changes
    - Add questions column to exam_schedule table to store exam questions
    - Add index for better performance
*/

-- Add questions column to exam_schedule table
ALTER TABLE exam_schedule
ADD COLUMN IF NOT EXISTS questions jsonb;

-- Create index for questions column
CREATE INDEX IF NOT EXISTS idx_exam_schedule_questions ON exam_schedule USING gin(questions);