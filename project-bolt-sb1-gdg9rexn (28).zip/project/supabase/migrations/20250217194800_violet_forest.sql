/*
  # Initial Schema Setup

  1. New Tables
    - `students`
      - `id` (uuid, primary key)
      - `name` (text)
      - `matricula` (text, unique)
      - `email` (text, unique)
      - `password` (text)
      - `salon` (text)
      - `semester` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `exam_results`
      - `id` (uuid, primary key)
      - `student_id` (uuid, foreign key)
      - `exam_type` (text)
      - `listening_score` (integer)
      - `structure_score` (integer)
      - `reading_score` (integer)
      - `total_score` (integer)
      - `taken_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create students table
CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  matricula text UNIQUE NOT NULL,
  email text UNIQUE NOT NULL,
  password text NOT NULL,
  salon text NOT NULL,
  semester text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create exam_results table
CREATE TABLE IF NOT EXISTS exam_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  exam_type text NOT NULL,
  listening_score integer,
  structure_score integer,
  reading_score integer,
  total_score integer,
  taken_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Teachers can manage all students"
  ON students
  FOR ALL
  TO authenticated
  USING (auth.role() = 'teacher')
  WITH CHECK (auth.role() = 'teacher');

CREATE POLICY "Students can read own data"
  ON students
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = matricula);

CREATE POLICY "Teachers can manage all exam results"
  ON exam_results
  FOR ALL
  TO authenticated
  USING (auth.role() = 'teacher')
  WITH CHECK (auth.role() = 'teacher');

CREATE POLICY "Students can read own exam results"
  ON exam_results
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.id = exam_results.student_id
      AND students.matricula = auth.uid()::text
    )
  );