/*
  # Remove Security Restrictions

  1. Changes
    - Disable RLS on tests table
    - Drop all existing policies
    - Allow unrestricted access
*/

-- Disable RLS completely
ALTER TABLE tests DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "allow_all_operations" ON tests;
DROP POLICY IF EXISTS "student_read_only" ON tests;
DROP POLICY IF EXISTS "teacher_full_access" ON tests;
DROP POLICY IF EXISTS "student_view_only" ON tests;