/*
  # Final Fix for Test Table RLS Policies

  1. Changes
    - Drop all existing policies
    - Create single, simple teacher policy
    - Recreate student viewing policy
    - Add fresh indexes

  2. Security
    - Simplify teacher access check
    - Maintain student access restrictions
*/

-- First, disable RLS to clean up
ALTER TABLE tests DISABLE ROW LEVEL SECURITY;

-- Drop ALL existing policies
DROP POLICY IF EXISTS "teacher_test_management_policy" ON tests;
DROP POLICY IF EXISTS "student_test_viewing_policy" ON tests;
DROP POLICY IF EXISTS "allow_teacher_management" ON tests;
DROP POLICY IF EXISTS "allow_student_viewing" ON tests;
DROP POLICY IF EXISTS "teacher_manage_tests" ON tests;
DROP POLICY IF EXISTS "student_view_tests" ON tests;

-- Re-enable RLS
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;

-- Create fresh, simple policies
CREATE POLICY "teacher_full_access"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "student_view_only"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Drop any existing indexes to avoid conflicts
DROP INDEX IF EXISTS idx_tests_type_level_v3;
DROP INDEX IF EXISTS idx_tests_access_v3;
DROP INDEX IF EXISTS idx_tests_type_level_v4;
DROP INDEX IF EXISTS idx_tests_access_v4;

-- Create fresh indexes
CREATE INDEX IF NOT EXISTS idx_tests_type_level ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_access ON tests(salon, semestre);