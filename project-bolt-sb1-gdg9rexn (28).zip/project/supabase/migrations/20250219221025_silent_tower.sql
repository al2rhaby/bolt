/*
  # Fix Tests Table Schema

  1. Changes
    - Add salons column to tests table
    - Update existing policies
    - Add indexes for performance

  2. Security
    - Maintain existing RLS policies
*/

-- Add salons column to tests table
ALTER TABLE tests ADD COLUMN IF NOT EXISTS salons text[];

-- Create index for the new column
CREATE INDEX IF NOT EXISTS idx_tests_salons ON tests USING gin(salons);

-- Update policies to include salons column
DROP POLICY IF EXISTS "teacher_full_access" ON tests;
DROP POLICY IF EXISTS "student_view_only" ON tests;

CREATE POLICY "teacher_full_access"
  ON tests
  FOR ALL 
  TO authenticated
  USING (
    auth.email() = 'mohamed' OR 
    created_by = 'mohamed'
  )
  WITH CHECK (
    auth.email() = 'mohamed' OR 
    auth.email() = created_by
  );

CREATE POLICY "student_view_only"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = ANY(tests.salons)
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );