/*
  # Fix Test Table Policies - Simplified Migration

  1. Changes
    - Reset and simplify test table policies
    - Add basic indexes for performance

  2. Security
    - Enable RLS
    - Add teacher management policy
    - Add student view policy
*/

-- Enable RLS
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;

-- Create teacher policy
CREATE POLICY "teacher_manage_tests"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create student policy
CREATE POLICY "student_view_tests"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Add essential indexes
CREATE INDEX IF NOT EXISTS idx_tests_type_level ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_salon_sem ON tests(salon, semestre);