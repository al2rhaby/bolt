-- Disable RLS on exam_schedule
ALTER TABLE exam_schedule DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "allow_teacher_schedule_management" ON exam_schedule;
DROP POLICY IF EXISTS "allow_student_schedule_viewing" ON exam_schedule;
DROP POLICY IF EXISTS "teacher_manage_schedule" ON exam_schedule;
DROP POLICY IF EXISTS "student_view_schedule" ON exam_schedule;

-- Add salon column if it doesn't exist
ALTER TABLE exam_schedule 
ADD COLUMN IF NOT EXISTS salon text;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_exam_schedule_salon ON exam_schedule(salon);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_test_id ON exam_schedule(test_id);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_date ON exam_schedule(date);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_status ON exam_schedule(status);