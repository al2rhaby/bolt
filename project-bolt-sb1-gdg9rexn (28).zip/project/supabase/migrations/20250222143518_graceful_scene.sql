/*
  # Fix matching questions schema

  1. Changes
    - Make correct_answer nullable for matching questions
    - Update constraints to handle different question types properly
    - Add appropriate indexes for performance

  2. Constraints
    - Multiple choice questions must have correct_answer
    - Matching questions must have correct_pairs
    - True/false questions must have is_true
*/

-- Drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;

-- Make correct_answer nullable
ALTER TABLE questions ALTER COLUMN correct_answer DROP NOT NULL;

-- Add new type check constraint
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  -- Multiple choice questions
  (type = 'multiple' AND correct_answer IS NOT NULL AND is_true IS NULL AND left_items IS NULL AND right_items IS NULL AND correct_pairs IS NULL) OR
  -- Matching questions
  (type = 'matching' AND correct_answer IS NULL AND is_true IS NULL AND left_items IS NOT NULL AND right_items IS NOT NULL AND correct_pairs IS NOT NULL) OR
  -- True/false questions
  (type = 'truefalse' AND correct_answer IS NULL AND is_true IS NOT NULL AND left_items IS NULL AND right_items IS NULL AND correct_pairs IS NULL)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type_test ON questions(type, test_id);
CREATE INDEX IF NOT EXISTS idx_questions_matching ON questions(test_id) WHERE type = 'matching';
CREATE INDEX IF NOT EXISTS idx_questions_truefalse ON questions(test_id) WHERE type = 'truefalse';
CREATE INDEX IF NOT EXISTS idx_questions_multiple ON questions(test_id) WHERE type = 'multiple';