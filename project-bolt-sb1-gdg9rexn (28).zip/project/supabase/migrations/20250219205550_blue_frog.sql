/*
  # Fix Test Table Policies - Final Version

  1. Changes
    - Reset and simplify test table policies
    - Add proper teacher access control
    - Add student view access
    - Add optimized indexes

  2. Security
    - Enable RLS
    - Add teacher management policy
    - Add student view policy
*/

-- Enable RLS
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;

-- Create policies for tests table
CREATE POLICY "allow_teacher_management"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "allow_student_viewing"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Add optimized indexes
CREATE INDEX IF NOT EXISTS idx_tests_combined ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_access ON tests(salon, semestre);