/*
  # Fix Passages RLS Policies

  1. Changes
    - Drop existing policies
    - Add proper RLS policies for teacher access
    - Add policies for student access
    - Update indexes for better performance

  2. Security
    - Enable RLS on passages table
    - Add teacher management policy
    - Add student read-only policy
*/

-- First disable RLS to clean up
ALTER TABLE passages DISABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "allow_all_operations" ON passages;

-- Re-enable RLS
ALTER TABLE passages ENABLE ROW LEVEL SECURITY;

-- Create teacher management policy
CREATE POLICY "teacher_manage_passages"
  ON passages
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create student read-only policy
CREATE POLICY "student_view_passages"
  ON passages
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM tests
      JOIN students ON students.salon = ANY(tests.salons)
      WHERE tests.id = passages.test_id
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Create or update indexes
CREATE INDEX IF NOT EXISTS idx_passages_test_id ON passages(test_id);
CREATE INDEX IF NOT EXISTS idx_passages_created_at ON passages(created_at);