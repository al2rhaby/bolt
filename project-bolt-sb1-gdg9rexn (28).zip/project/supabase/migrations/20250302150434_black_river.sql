/*
  # Fix TOEFL Statistics

  1. Changes
    - Add missing columns to exam_results table
    - Add ON DELETE CASCADE to foreign key references
    - Add composite indexes for better query performance
    - Add trigger for automatic status updates
*/

-- Add missing columns if they don't exist
ALTER TABLE exam_results
ADD COLUMN IF NOT EXISTS exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS status text CHECK (status IN ('completed', 'incomplete')) DEFAULT 'incomplete',
ADD COLUMN IF NOT EXISTS completion_time timestamptz;

-- Create composite indexes for better performance
CREATE INDEX IF NOT EXISTS idx_exam_results_student_exam ON exam_results(student_id, exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_type_status ON exam_results(exam_type, status);
CREATE INDEX IF NOT EXISTS idx_exam_results_completion ON exam_results(completion_time);

-- Create function to update exam status
CREATE OR REPLACE FUNCTION update_exam_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Update exam_schedule status when all sections are completed
  IF NEW.status = 'completed' THEN
    UPDATE exam_schedule
    SET status = 'completed'
    WHERE id = NEW.exam_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for exam status updates
DROP TRIGGER IF EXISTS trigger_update_exam_status ON exam_results;
CREATE TRIGGER trigger_update_exam_status
  AFTER INSERT OR UPDATE OF status
  ON exam_results
  FOR EACH ROW
  EXECUTE FUNCTION update_exam_status();