/*
  # Fix Test Table Policies - Final Version

  1. Changes
    - Drop all existing policies
    - Recreate policies with proper names
    - Add optimized indexes

  2. Security
    - Enable RLS
    - Add teacher management policy
    - Add student view policy
*/

-- Drop existing policies
DROP POLICY IF EXISTS "allow_teacher_management" ON tests;
DROP POLICY IF EXISTS "allow_student_viewing" ON tests;
DROP POLICY IF EXISTS "teacher_manage_tests" ON tests;
DROP POLICY IF EXISTS "student_view_tests" ON tests;
DROP POLICY IF EXISTS "Teachers can manage tests" ON tests;
DROP POLICY IF EXISTS "Students can view assigned tests" ON tests;
DROP POLICY IF EXISTS "Allow teacher test management" ON tests;
DROP POLICY IF EXISTS "Allow student test viewing" ON tests;

-- Create new policies with unique names
CREATE POLICY "teacher_test_management_policy"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "student_test_viewing_policy"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Add optimized indexes (with unique names)
CREATE INDEX IF NOT EXISTS idx_tests_type_level_v2 ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_access_v2 ON tests(salon, semestre);