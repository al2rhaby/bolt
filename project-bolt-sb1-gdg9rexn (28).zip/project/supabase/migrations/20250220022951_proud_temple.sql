-- Add underlined_words column to questions table
ALTER TABLE questions 
ADD COLUMN IF NOT EXISTS underlined_words jsonb;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_questions_underlined_words ON questions USING gin(underlined_words);