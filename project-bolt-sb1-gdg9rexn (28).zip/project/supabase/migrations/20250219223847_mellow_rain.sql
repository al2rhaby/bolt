/*
  # Create Exam Schedule Table

  1. New Tables
    - `exam_schedule`
      - `id` (uuid, primary key)
      - `test_id` (uuid, foreign key to tests)
      - `date` (date)
      - `time` (time)
      - `duration` (integer)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on exam_schedule table
    - Add policies for teacher and student access
    - Add indexes for performance

  3. Changes
    - Add foreign key constraint to tests table
    - Add status enum type
*/

-- Create exam status type
CREATE TYPE exam_status AS ENUM ('upcoming', 'ongoing', 'completed');

-- Create exam_schedule table
CREATE TABLE IF NOT EXISTS exam_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  date date NOT NULL,
  time time NOT NULL,
  duration integer NOT NULL,
  status exam_status DEFAULT 'upcoming',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE exam_schedule ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "teacher_manage_schedule"
  ON exam_schedule
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "student_view_schedule"
  ON exam_schedule
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM tests
      JOIN students ON students.salon = ANY(tests.salons)
      WHERE tests.id = exam_schedule.test_id
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_exam_schedule_test_id ON exam_schedule(test_id);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_date ON exam_schedule(date);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_status ON exam_schedule(status);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_exam_schedule_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_exam_schedule_updated_at
  BEFORE UPDATE ON exam_schedule
  FOR EACH ROW
  EXECUTE FUNCTION update_exam_schedule_updated_at();