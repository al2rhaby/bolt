-- Add parent_test_id column to tests table
ALTER TABLE tests 
ADD COLUMN IF NOT EXISTS parent_test_id uuid REFERENCES tests(id) ON DELETE CASCADE;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_tests_parent_id ON tests(parent_test_id);