/*
  # Fix Structure Questions Schema

  1. Changes
    - Simplify question type constraints
    - Update column requirements for different question types
    - Add proper indexes
    - Clean up existing data

  2. Security
    - Maintain existing RLS policies
*/

-- Drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;
ALTER TABLE questions DROP CONSTRAINT IF EXISTS questions_type_check;

-- Make sure underlined_words column exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'underlined_words'
  ) THEN
    ALTER TABLE questions ADD COLUMN underlined_words jsonb;
  END IF;
END $$;

-- Clean up any invalid data
UPDATE questions 
SET choices = '[]'::jsonb WHERE choices IS NULL;

-- Add type check constraint
ALTER TABLE questions
ADD CONSTRAINT questions_type_check
CHECK (type IN ('multiple', 'truefalse', 'matching', 'underline'));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);
CREATE INDEX IF NOT EXISTS idx_questions_underlined_words ON questions USING gin(underlined_words);
CREATE INDEX IF NOT EXISTS idx_questions_test_type ON questions(test_id, type);