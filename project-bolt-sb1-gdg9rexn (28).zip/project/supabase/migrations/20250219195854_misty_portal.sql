/*
  # Add Student Answers Table

  1. New Tables
    - `student_answers`
      - `id` (uuid, primary key)
      - `student_id` (uuid, references students)
      - `test_id` (uuid, references tests)
      - `question_id` (uuid, references questions)
      - `answer` (jsonb, stores answer data)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `student_answers` table
    - Add policies for students to manage their own answers
    - Add policies for teachers to view all answers

  3. Indexes
    - Add indexes for efficient querying
*/

-- Create student_answers table
CREATE TABLE IF NOT EXISTS student_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  question_id uuid REFERENCES questions(id) ON DELETE CASCADE,
  answer jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(student_id, test_id, question_id)
);

-- Enable RLS
ALTER TABLE student_answers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Students can manage their own answers"
  ON student_answers
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.id = student_answers.student_id
      AND students.email = auth.email()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.id = student_answers.student_id
      AND students.email = auth.email()
    )
  );

CREATE POLICY "Teachers can view all answers"
  ON student_answers
  FOR SELECT
  TO authenticated
  USING (auth.email() = 'mohamed');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS student_answers_student_id_idx ON student_answers(student_id);
CREATE INDEX IF NOT EXISTS student_answers_test_id_idx ON student_answers(test_id);
CREATE INDEX IF NOT EXISTS student_answers_question_id_idx ON student_answers(question_id);
CREATE INDEX IF NOT EXISTS student_answers_composite_idx ON student_answers(student_id, test_id);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_student_answers_updated_at
  BEFORE UPDATE ON student_answers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add function to calculate student scores
CREATE OR REPLACE FUNCTION calculate_student_score(p_student_id uuid, p_test_id uuid)
RETURNS TABLE (
  total_questions bigint,
  correct_answers bigint,
  score numeric
) AS $$
BEGIN
  RETURN QUERY
  WITH question_count AS (
    SELECT count(*) as total
    FROM questions
    WHERE test_id = p_test_id
  ),
  correct_count AS (
    SELECT count(*) as correct
    FROM student_answers sa
    JOIN questions q ON q.id = sa.question_id
    WHERE sa.student_id = p_student_id
    AND sa.test_id = p_test_id
    AND sa.answer = q.correct_answer
  )
  SELECT 
    qc.total as total_questions,
    COALESCE(cc.correct, 0) as correct_answers,
    CASE 
      WHEN qc.total > 0 THEN 
        ROUND((COALESCE(cc.correct, 0)::numeric / qc.total::numeric) * 100, 2)
      ELSE 0
    END as score
  FROM question_count qc
  LEFT JOIN correct_count cc ON true;
END;
$$ LANGUAGE plpgsql;