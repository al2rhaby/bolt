/*
  # Fix questions table schema

  1. Changes
    - Add missing columns for different question types
    - Update constraints to handle all question types properly
    - Add appropriate indexes

  2. New Columns
    - `is_true` for true/false questions
    - `left_items` and `right_items` for matching questions
    - `correct_pairs` for matching questions

  3. Constraints
    - Ensure question type matches column usage
    - Allow NULL values for type-specific columns
*/

-- Drop existing constraint if it exists
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_truefalse_type;

-- Add columns for different question types if they don't exist
DO $$ 
BEGIN
  -- For true/false questions
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'is_true'
  ) THEN
    ALTER TABLE questions ADD COLUMN is_true boolean;
  END IF;

  -- For matching questions
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'left_items'
  ) THEN
    ALTER TABLE questions ADD COLUMN left_items jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'right_items'
  ) THEN
    ALTER TABLE questions ADD COLUMN right_items jsonb;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'questions' AND column_name = 'correct_pairs'
  ) THEN
    ALTER TABLE questions ADD COLUMN correct_pairs jsonb;
  END IF;
END $$;

-- Add type check constraint
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  (type = 'truefalse' AND is_true IS NOT NULL AND left_items IS NULL AND right_items IS NULL AND correct_pairs IS NULL) OR
  (type = 'matching' AND is_true IS NULL AND left_items IS NOT NULL AND right_items IS NOT NULL AND correct_pairs IS NOT NULL) OR
  (type = 'multiple' AND is_true IS NULL AND left_items IS NULL AND right_items IS NULL AND correct_pairs IS NULL)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_questions_type_test ON questions(type, test_id);
CREATE INDEX IF NOT EXISTS idx_questions_matching ON questions(test_id) WHERE type = 'matching';
CREATE INDEX IF NOT EXISTS idx_questions_truefalse ON questions(test_id) WHERE type = 'truefalse';
CREATE INDEX IF NOT EXISTS idx_questions_multiple ON questions(test_id) WHERE type = 'multiple';