/*
  # Add is_true column for true/false questions

  1. Changes
    - Add is_true column to questions table for true/false questions
    - Create index for better performance
    - Add check constraint to ensure valid values
*/

-- Add is_true column if it doesn't exist
ALTER TABLE questions 
ADD COLUMN IF NOT EXISTS is_true boolean;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_questions_is_true ON questions(is_true);

-- Add check constraint to ensure type matches is_true usage
ALTER TABLE questions
ADD CONSTRAINT check_truefalse_type 
CHECK (
  (type = 'truefalse' AND is_true IS NOT NULL) OR
  (type != 'truefalse' AND is_true IS NULL)
);