/*
  # Fix TOEFL exam database issues

  1. Changes
    - Remove test_id dependency from student_answers
    - Fix student progress tracking
    - Update exam results structure
    - Add proper RLS policies

  2. Security
    - Enable RLS on all tables
    - Add proper policies for students and teachers
*/

-- Update student_answers table
ALTER TABLE student_answers
DROP CONSTRAINT IF EXISTS student_answers_test_id_fkey,
ALTER COLUMN test_id DROP NOT NULL;

-- Update exam_results table
ALTER TABLE exam_results
DROP CONSTRAINT IF EXISTS exam_results_test_id_fkey,
ALTER COLUMN test_id DROP NOT NULL;

-- Create function for handling student progress
CREATE OR REPLACE FUNCTION handle_student_progress(
  p_student_id uuid,
  p_exam_id uuid,
  p_section text
) RETURNS void AS $$
DECLARE
  v_existing_sections text[];
BEGIN
  -- First try to get existing progress
  SELECT sections_completed INTO v_existing_sections
  FROM student_progress
  WHERE student_id = p_student_id AND exam_id = p_exam_id;

  IF v_existing_sections IS NULL THEN
    -- No existing progress, insert new
    INSERT INTO student_progress (
      student_id,
      exam_id,
      sections_completed,
      last_activity
    ) 
    VALUES (
      p_student_id,
      p_exam_id,
      ARRAY[p_section],
      CURRENT_TIMESTAMP
    );
  ELSE
    -- Update existing progress if section not already completed
    IF NOT (p_section = ANY(v_existing_sections)) THEN
      UPDATE student_progress
      SET 
        sections_completed = array_append(sections_completed, p_section),
        last_activity = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
      WHERE 
        student_id = p_student_id AND 
        exam_id = p_exam_id;
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Drop existing policies
DROP POLICY IF EXISTS "manage_student_progress" ON student_progress;
DROP POLICY IF EXISTS "manage_exam_results" ON exam_results;
DROP POLICY IF EXISTS "manage_student_answers" ON student_answers;

-- Create new unified policies
CREATE POLICY "allow_student_access"
  ON student_progress
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

CREATE POLICY "allow_exam_results"
  ON exam_results
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

CREATE POLICY "allow_student_answers"
  ON student_answers
  FOR ALL
  TO authenticated
  USING (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  )
  WITH CHECK (
    auth.uid()::text = student_id::text OR 
    auth.email() = 'mohamed'
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_student_progress_composite 
  ON student_progress(student_id, exam_id);
CREATE INDEX IF NOT EXISTS idx_student_answers_composite 
  ON student_answers(student_id, exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_composite 
  ON exam_results(student_id, exam_id);