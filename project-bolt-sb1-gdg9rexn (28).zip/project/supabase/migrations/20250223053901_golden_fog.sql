/*
  # Database Schema Update
  
  1. Tables
    - tests: Main table for storing test information
    - questions: Table for storing test questions
    - exam_schedule: Table for scheduling exams
  
  2. Indexes
    - Added performance optimized indexes for common queries
    - Added GIN index for jsonb columns
  
  3. Constraints
    - Added type checks for test and question types
    - Added foreign key constraints
*/

-- Create tests table if it doesn't exist
CREATE TABLE IF NOT EXISTS tests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  type text NOT NULL CHECK (type IN ('TOEFL', 'Unit')),
  level text CHECK (level IN ('Basic', 'Intermediate', 'Advanced')),
  carrera text,
  semestre text,
  grupo text,
  profesor text,
  salons text[],
  audio_url text,
  section text,
  parent_test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  created_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create questions table if it doesn't exist
CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('multiple', 'truefalse', 'matching', 'underline')),
  text text NOT NULL,
  choices jsonb,
  correct_answer jsonb,
  underlined_words jsonb,
  left_items jsonb,
  right_items jsonb,
  correct_pairs jsonb,
  passage_id uuid,
  passage_title text,
  passage_content text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create exam_schedule table if it doesn't exist
CREATE TABLE IF NOT EXISTS exam_schedule (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  test_id uuid REFERENCES tests(id) ON DELETE CASCADE,
  date date NOT NULL,
  time time NOT NULL,
  duration integer NOT NULL,
  status text CHECK (status IN ('upcoming', 'ongoing', 'completed')) DEFAULT 'upcoming',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tests_type ON tests(type);
CREATE INDEX IF NOT EXISTS idx_tests_parent_id ON tests(parent_test_id);
CREATE INDEX IF NOT EXISTS idx_tests_section ON tests(section);
CREATE INDEX IF NOT EXISTS idx_questions_test_id ON questions(test_id);
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);
CREATE INDEX IF NOT EXISTS idx_questions_underlined_words ON questions USING gin(underlined_words);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_test_id ON exam_schedule(test_id);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_date ON exam_schedule(date);
CREATE INDEX IF NOT EXISTS idx_exam_schedule_status ON exam_schedule(status);

-- Create or replace the trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS update_tests_updated_at ON tests;
DROP TRIGGER IF EXISTS update_questions_updated_at ON questions;
DROP TRIGGER IF EXISTS update_exam_schedule_updated_at ON exam_schedule;

-- Create triggers
CREATE TRIGGER update_tests_updated_at
  BEFORE UPDATE ON tests
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_questions_updated_at
  BEFORE UPDATE ON questions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_exam_schedule_updated_at
  BEFORE UPDATE ON exam_schedule
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();