-- First, disable RLS to clean up
ALTER TABLE tests DISABLE ROW LEVEL SECURITY;

-- Drop ALL existing policies
DROP POLICY IF EXISTS "teacher_test_management_policy" ON tests;
DROP POLICY IF EXISTS "student_test_viewing_policy" ON tests;
DROP POLICY IF EXISTS "allow_teacher_management" ON tests;
DROP POLICY IF EXISTS "allow_student_viewing" ON tests;
DROP POLICY IF EXISTS "teacher_manage_tests" ON tests;
DROP POLICY IF EXISTS "student_view_tests" ON tests;
DROP POLICY IF EXISTS "teacher_full_access" ON tests;
DROP POLICY IF EXISTS "student_view_only" ON tests;

-- Re-enable RLS
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;

-- Add created_by column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tests' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE tests ADD COLUMN created_by text;
  END IF;
END $$;

-- Create fresh, simple policies
CREATE POLICY "teacher_full_access"
  ON tests
  FOR ALL 
  TO authenticated
  USING (
    auth.email() = 'mohamed' OR 
    created_by = 'mohamed'
  )
  WITH CHECK (
    auth.email() = 'mohamed' OR 
    auth.email() = created_by
  );

CREATE POLICY "student_view_only"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_tests_type_level ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_access ON tests(salon, semestre);
CREATE INDEX IF NOT EXISTS idx_tests_created_by ON tests(created_by);