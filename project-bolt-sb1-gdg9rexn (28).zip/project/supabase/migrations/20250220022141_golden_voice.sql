-- Add section column to tests table
ALTER TABLE tests 
ADD COLUMN IF NOT EXISTS section text;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_tests_section ON tests(section);