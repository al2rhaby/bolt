/*
  # Add audio_url to tests table

  1. Changes
    - Add audio_url column to tests table
    - Add index for performance

  2. Notes
    - No RLS policies needed
    - Column allows storing MP3 URLs for listening sections
*/

-- Add audio_url column to tests table
ALTER TABLE tests 
ADD COLUMN IF NOT EXISTS audio_url text;

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_tests_audio_url ON tests(audio_url);