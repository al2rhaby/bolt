-- Disable RLS for all tables
ALTER TABLE tests DISABLE ROW LEVEL SECURITY;
ALTER TABLE questions DISABLE ROW LEVEL SECURITY;
ALTER TABLE students DISABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results DISABLE ROW LEVEL SECURITY;
ALTER TABLE exam_schedule DISABLE ROW LEVEL SECURITY;
ALTER TABLE passages DISABLE ROW LEVEL SECURITY;
ALTER TABLE toefl_folders DISABLE ROW LEVEL SECURITY;
ALTER TABLE toefl_sections DISABLE ROW LEVEL SECURITY;
ALTER TABLE toefl_questions DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DROP POLICY IF EXISTS "teacher_full_access" ON tests;
DROP POLICY IF EXISTS "student_view_only" ON tests;
DROP POLICY IF EXISTS "allow_all_operations" ON tests;
DROP POLICY IF EXISTS "student_read_only" ON tests;
DROP POLICY IF EXISTS "teacher_manage_folders" ON toefl_folders;
DROP POLICY IF EXISTS "teacher_manage_sections" ON toefl_sections;
DROP POLICY IF EXISTS "teacher_manage_questions" ON toefl_questions;
DROP POLICY IF EXISTS "Teachers can manage all students" ON students;
DROP POLICY IF EXISTS "Students can read own data" ON students;
DROP POLICY IF EXISTS "Allow student registration" ON students;
DROP POLICY IF EXISTS "Teachers can view all students" ON students;
DROP POLICY IF EXISTS "Teachers can manage students" ON students;
DROP POLICY IF EXISTS "Students can read own data" ON students;
DROP POLICY IF EXISTS "Teachers can manage all exam results" ON exam_results;
DROP POLICY IF EXISTS "Students can read own exam results" ON exam_results;
DROP POLICY IF EXISTS "teacher_manage_schedule" ON exam_schedule;
DROP POLICY IF EXISTS "student_view_schedule" ON exam_schedule;
DROP POLICY IF EXISTS "allow_teacher_schedule_management" ON exam_schedule;
DROP POLICY IF EXISTS "allow_student_schedule_viewing" ON exam_schedule;