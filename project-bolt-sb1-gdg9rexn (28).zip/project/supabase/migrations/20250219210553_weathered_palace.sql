/*
  # Fix Teacher Authentication Policies

  1. Changes
    - Drop existing policies
    - Add new simplified teacher policy
    - Add student viewing policy
    - Add performance indexes

  2. Security
    - Enable RLS on tests table
    - Restrict access to only teacher account with email 'mohamed'
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "teacher_test_management_policy" ON tests;
DROP POLICY IF EXISTS "student_test_viewing_policy" ON tests;

-- Create new policies for tests table
CREATE POLICY "teacher_test_management_policy"
  ON tests
  FOR ALL 
  TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "student_test_viewing_policy"
  ON tests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM students
      WHERE students.salon = tests.salon
      AND students.semester = tests.semestre
      AND students.email = auth.email()
    )
  );

-- Add optimized indexes
CREATE INDEX IF NOT EXISTS idx_tests_type_level_v4 ON tests(type, level);
CREATE INDEX IF NOT EXISTS idx_tests_access_v4 ON tests(salon, semestre);