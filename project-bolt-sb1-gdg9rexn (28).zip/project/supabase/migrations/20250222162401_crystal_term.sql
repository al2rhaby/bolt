/*
  # Fix true/false question handling

  1. Changes
    - Add choices array for true/false questions
    - Update check constraint to handle true/false questions correctly
    - Add index for question types

  2. Security
    - No changes to RLS policies
*/

-- Drop existing constraint
ALTER TABLE questions DROP CONSTRAINT IF EXISTS check_question_type_columns;

-- Add new constraint with updated true/false handling
ALTER TABLE questions
ADD CONSTRAINT check_question_type_columns
CHECK (
  -- Multiple choice questions
  (
    type = 'multiple' AND 
    correct_answer IS NOT NULL AND 
    choices IS NOT NULL AND
    is_true IS NULL AND 
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL
  ) OR
  -- Matching questions
  (
    type = 'matching' AND 
    correct_answer IS NULL AND 
    choices IS NULL AND
    is_true IS NULL AND 
    left_items IS NOT NULL AND 
    right_items IS NOT NULL AND 
    correct_pairs IS NOT NULL
  ) OR
  -- True/false questions
  (
    type = 'truefalse' AND 
    correct_answer IS NOT NULL AND
    choices IS NOT NULL AND
    is_true IS NULL AND 
    left_items IS NULL AND 
    right_items IS NULL AND 
    correct_pairs IS NULL
  )
);

-- Add index for question types
CREATE INDEX IF NOT EXISTS idx_questions_type ON questions(type);