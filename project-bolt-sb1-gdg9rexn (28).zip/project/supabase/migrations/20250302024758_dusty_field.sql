/*
  # Fix exam progress and results tables

  1. Changes
    - Create new timestamp trigger function
    - Add student progress table
    - Update exam results table
    - Add proper indexes and policies

  2. Tables Modified
    - student_progress
    - exam_results
    - student_answers
*/

-- Create new timestamp trigger function with a different name
CREATE OR REPLACE FUNCTION set_updated_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate student_progress table with proper structure
DROP TABLE IF EXISTS student_progress;
CREATE TABLE student_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  exam_id uuid NOT NULL REFERENCES exam_schedule(id) ON DELETE CASCADE,
  sections_completed text[] DEFAULT ARRAY[]::text[],
  last_activity timestamptz DEFAULT CURRENT_TIMESTAMP,
  created_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  updated_at timestamptz DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(student_id, exam_id)
);

-- Update exam_results table
ALTER TABLE exam_results 
DROP CONSTRAINT IF EXISTS exam_results_test_id_fkey;

ALTER TABLE exam_results
ADD COLUMN IF NOT EXISTS exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS status text CHECK (status IN ('completed', 'incomplete')),
ADD COLUMN IF NOT EXISTS completion_time timestamptz DEFAULT CURRENT_TIMESTAMP;

-- Update student_answers table
ALTER TABLE student_answers
ADD COLUMN IF NOT EXISTS exam_id uuid REFERENCES exam_schedule(id) ON DELETE CASCADE;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_student_progress_student ON student_progress(student_id);
CREATE INDEX IF NOT EXISTS idx_student_progress_exam ON student_progress(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_student ON exam_results(student_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_exam ON exam_results(exam_id);
CREATE INDEX IF NOT EXISTS idx_exam_results_status ON exam_results(status);
CREATE INDEX IF NOT EXISTS idx_student_answers_exam ON student_answers(exam_id);

-- Add triggers for updated_at timestamps
CREATE TRIGGER set_timestamp_student_progress
  BEFORE UPDATE ON student_progress
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_timestamp();

CREATE TRIGGER set_timestamp_exam_results
  BEFORE UPDATE ON exam_results
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_timestamp();

CREATE TRIGGER set_timestamp_student_answers
  BEFORE UPDATE ON student_answers
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_timestamp();

-- Enable RLS
ALTER TABLE student_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE student_answers ENABLE ROW LEVEL SECURITY;

-- Drop existing policies first
DROP POLICY IF EXISTS "Students can manage their own answers" ON student_answers;
DROP POLICY IF EXISTS "Teachers can view all answers" ON student_answers;

-- Create policies
CREATE POLICY "student_progress_policy"
  ON student_progress
  FOR ALL
  TO authenticated
  USING (auth.uid()::text = student_id::text)
  WITH CHECK (auth.uid()::text = student_id::text);

CREATE POLICY "teacher_progress_policy"
  ON student_progress
  FOR SELECT
  TO authenticated
  USING (auth.email() = 'mohamed');

CREATE POLICY "student_answers_policy"
  ON student_answers
  FOR ALL
  TO authenticated
  USING (auth.uid()::text = student_id::text)
  WITH CHECK (auth.uid()::text = student_id::text);

CREATE POLICY "teacher_answers_policy"
  ON student_answers
  FOR SELECT
  TO authenticated
  USING (auth.email() = 'mohamed');