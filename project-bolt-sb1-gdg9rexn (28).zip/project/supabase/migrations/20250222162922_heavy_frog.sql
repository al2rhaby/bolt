/*
  # Unit Exam Database Schema

  1. New Tables
    - units (stores unit information)
    - unit_exams (stores exam metadata)
    - unit_questions (stores exam questions)
    - unit_choices (stores multiple choice options)
    - unit_matching_pairs (stores matching question pairs)
    - unit_exam_results (stores student exam results)

  2. Security
    - Enable RLS on all tables
    - Add policies for teacher and student access

  3. Relationships
    - Foreign key constraints ensure data integrity
    - Cascading deletes where appropriate
*/

-- Create units table
CREATE TABLE IF NOT EXISTS units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by text NOT NULL
);

-- Create unit_exams table
CREATE TABLE IF NOT EXISTS unit_exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  unit_id uuid REFERENCES units(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  level text CHECK (level IN ('Basic', 'Intermediate', 'Advanced')),
  total_points integer NOT NULL DEFAULT 0,
  duration integer NOT NULL DEFAULT 60, -- in minutes
  status text CHECK (status IN ('draft', 'active', 'archived')) DEFAULT 'draft',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by text NOT NULL,
  carrera text,
  semestre text,
  grupo text,
  salons text[]
);

-- Create unit_questions table
CREATE TABLE IF NOT EXISTS unit_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid REFERENCES unit_exams(id) ON DELETE CASCADE,
  question_type text NOT NULL CHECK (question_type IN ('multiple_choice', 'true_false', 'matching')),
  question_text text NOT NULL,
  points integer NOT NULL DEFAULT 1,
  correct_answer jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  created_by text NOT NULL,
  CONSTRAINT valid_correct_answer CHECK (
    (question_type = 'multiple_choice' AND correct_answer ? 'option_id') OR
    (question_type = 'true_false' AND correct_answer ? 'is_true') OR
    (question_type = 'matching' AND correct_answer ? 'pairs')
  )
);

-- Create unit_choices table for multiple choice questions
CREATE TABLE IF NOT EXISTS unit_choices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid REFERENCES unit_questions(id) ON DELETE CASCADE,
  choice_text text NOT NULL,
  is_correct boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create unit_matching_pairs table for matching questions
CREATE TABLE IF NOT EXISTS unit_matching_pairs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid REFERENCES unit_questions(id) ON DELETE CASCADE,
  left_item text NOT NULL,
  right_item text NOT NULL,
  pair_order integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE (question_id, pair_order)
);

-- Create unit_exam_results table
CREATE TABLE IF NOT EXISTS unit_exam_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid REFERENCES unit_exams(id) ON DELETE CASCADE,
  student_id uuid REFERENCES students(id) ON DELETE CASCADE,
  start_time timestamptz NOT NULL DEFAULT now(),
  completion_time timestamptz,
  total_points integer NOT NULL DEFAULT 0,
  answers jsonb NOT NULL DEFAULT '{}',
  status text CHECK (status IN ('in_progress', 'completed', 'abandoned')) DEFAULT 'in_progress',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE units ENABLE ROW LEVEL SECURITY;
ALTER TABLE unit_exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE unit_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE unit_choices ENABLE ROW LEVEL SECURITY;
ALTER TABLE unit_matching_pairs ENABLE ROW LEVEL SECURITY;
ALTER TABLE unit_exam_results ENABLE ROW LEVEL SECURITY;

-- Create policies for teacher access
CREATE POLICY "teachers_manage_units" ON units
  FOR ALL TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "teachers_manage_exams" ON unit_exams
  FOR ALL TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "teachers_manage_questions" ON unit_questions
  FOR ALL TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "teachers_manage_choices" ON unit_choices
  FOR ALL TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

CREATE POLICY "teachers_manage_matching" ON unit_matching_pairs
  FOR ALL TO authenticated
  USING (auth.email() = 'mohamed')
  WITH CHECK (auth.email() = 'mohamed');

-- Create policies for student access to exam results
CREATE POLICY "students_manage_own_results" ON unit_exam_results
  FOR ALL TO authenticated
  USING (auth.uid() = student_id)
  WITH CHECK (auth.uid() = student_id);

-- Create indexes for better performance
CREATE INDEX idx_unit_exams_unit ON unit_exams(unit_id);
CREATE INDEX idx_unit_questions_exam ON unit_questions(exam_id);
CREATE INDEX idx_unit_choices_question ON unit_choices(question_id);
CREATE INDEX idx_unit_matching_question ON unit_matching_pairs(question_id);
CREATE INDEX idx_unit_results_exam ON unit_exam_results(exam_id);
CREATE INDEX idx_unit_results_student ON unit_exam_results(student_id);
CREATE INDEX idx_unit_exams_status ON unit_exams(status);
CREATE INDEX idx_unit_results_status ON unit_exam_results(status);

-- Add triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_units_updated_at
  BEFORE UPDATE ON units
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_unit_exams_updated_at
  BEFORE UPDATE ON unit_exams
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_unit_questions_updated_at
  BEFORE UPDATE ON unit_questions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_unit_results_updated_at
  BEFORE UPDATE ON unit_exam_results
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();